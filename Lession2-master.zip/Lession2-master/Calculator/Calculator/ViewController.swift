//
//  ViewController.swift
//  Calculator
//
//  Created by Da on 7/12/18.
//  Copyright © 2018 Da. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    // MARK: IBOUTLET
    
    @IBOutlet weak var result_Label: UILabel!
    
    @IBOutlet weak var number_0_Button: UIButton!
    @IBOutlet weak var number_1_Button: UIButton!
    @IBOutlet weak var number_2_Button: UIButton!
    @IBOutlet weak var number_3_Button: UIButton!
    @IBOutlet weak var number_4_Button: UIButton!
    @IBOutlet weak var number_5_Button: UIButton!
    @IBOutlet weak var number_6_Button: UIButton!
    @IBOutlet weak var number_7_Button: UIButton!
    @IBOutlet weak var number_8_Button: UIButton!
    @IBOutlet weak var number_9_Button: UIButton!
    
    @IBOutlet weak var operation_doc_Button: UIButton!
    @IBOutlet weak var operation_equal_Button: UIButton!
    @IBOutlet weak var operation_sum_Button: UIButton!
    @IBOutlet weak var operation_subtraction_Button: UIButton!
    @IBOutlet weak var operation_mul_Button: UIButton!
    @IBOutlet weak var operation_div_Button: UIButton!
    
    @IBOutlet weak var operation_ac_Button: UIButton!
    @IBOutlet weak var operation_opposite_Button: UIButton!
    @IBOutlet weak var operation_percent_Button: UIButton!
    
    // MARK: VARIABLES
    
    var result: CGFloat = 0 {
        didSet {
            result_Label.text = "\(result)"
        }
    }
    
    var number_status: Bool = true
    var doc_status: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        result = 0
        
        addBorder(cornerRadius: 1,
                  width: 1,
                  color: UIColor(red: 154/255, green: 154/255, blue: 154/255, alpha: 1),
                  arrButton:
                  number_0_Button,
                  number_1_Button,
                  number_2_Button,
                  number_3_Button,
                  number_4_Button,
                  number_5_Button,
                  number_6_Button,
                  number_7_Button,
                  number_8_Button,
                  number_9_Button,
                  
                  operation_doc_Button,
                  operation_equal_Button,
                  operation_sum_Button,
                  operation_subtraction_Button,
                  operation_mul_Button,
                  operation_div_Button,
                  operation_ac_Button,
                  operation_opposite_Button,
                  operation_percent_Button
        
                  )
    }
    // MARK: FUCNCTION
    func addBorder( cornerRadius: CGFloat, width: CGFloat, color: UIColor, arrButton: UIButton... ) {
        for button in arrButton {
            button.cornerRadius = cornerRadius
            button.borderWidth = width
            button.borderColor = color
        }
    }
    // MARK: ACTION
    
    @IBAction func touch_number_0_Button(_ sender: Any) {
        if doc_status {
            result_Label.text = result_Label.text! + "."
            return
        }
    }
    
    @IBAction func touch_number_1_Button(_ sender: Any) {
        result_Label.text = result_Label.text! + "1"
    }
    
    @IBAction func touch_number_2_Button(_ sender: Any) {

    }
    
    @IBAction func touch_number_3_Button(_ sender: Any) {

    }
    
    @IBAction func touch_number_4_Button(_ sender: Any) {

    }
    
    @IBAction func touch_number_5_Button(_ sender: Any) {

    }
    
    @IBAction func touch_number_6_Button(_ sender: Any) {

    }
    
    @IBAction func touch_number_7_Button(_ sender: Any) {

    }
    
    @IBAction func touch_number_8_Button(_ sender: Any) {
 
    }
    
    @IBAction func touch_number_9_Button(_ sender: Any) {

    }
    @IBAction func touch_operation_doc_Button(_ sender: Any) {
        doc_status = true
    }
    
    @IBAction func touch_operation_sum_Button(_ sender: Any) {
    }
    
    @IBAction func touch_operation_sub_Button(_ sender: Any) {
    }
    
    @IBAction func touch_operation_mul_Button(_ sender: Any) {
    }
    
    @IBAction func touch_operation_div_Button(_ sender: Any) {
    }
    
    @IBAction func touch_operation_ac_Button(_ sender: Any) {
        result_Label.text = "0"
    }
    
    @IBAction func touch_operation_opposite_Button(_ sender: Any) {
    }
    @IBAction func touch_operation_percent_Button(_ sender: Any) {
    }
    @IBAction func touch_operation_result_Button(_ sender: Any) {
        guard let n = NumberFormatter().number(from: result_Label.text!) else { return }
        result = CGFloat(truncating: n)
    }
    
}



