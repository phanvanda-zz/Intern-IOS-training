

//
//  SecondViewController.swift
//  Lession7
//
//  Created by Da on 7/23/18.
//  Copyright © 2018 Da. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    @IBOutlet weak var secondVCLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

//        NotificationCenter.default.addObserver(self,
//                                               selector: #selector(doThisWhenNotify),
//                                               name: NSNotification.Name(myNotificationKey),
//                                               object: nil)
    }
//    @objc func doThisWhenNotify() {
//        print("I've sent a spark!")
//    }
    @IBAction func tabToNotifyBack(_ sender: Any) {
//        NotificationCenter.default.post(name: Notification.Name(rawValue: myNotificationKey),
//                                        object: self)
        NotificationCenter.default.post(name: Notification.Name(rawValue: myNotificationKey),
                                        object: nil,
                                        userInfo: ["key":"aaaaaa"])
        secondVCLabel.text = "Notification Completed!😜"
    }
 
    
}










