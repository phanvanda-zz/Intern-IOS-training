//
//  FirstViewController.swift
//  Lession7
//
//  Created by Da on 7/23/18.
//  Copyright © 2018 Da. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    @IBOutlet weak var firstVCLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
//        NotificationCenter.default.addObserver(self,
//                                               selector: #selector(doSomethingAfterNotified),
//                                               name: NSNotification.Name(rawValue: myNotificationKey),
//                                               object: nil)
        NotificationCenter.default.addObserver(forName: NSNotification.Name(rawValue: myNotificationKey),
                                               object: nil,
                                               queue: nil,
                                               using:catchNotification(notification:))
    }
    @objc func catchNotification(notification: Notification) {
        if let noti = notification.userInfo {
            if let value = noti["key"] as? String {
                self.firstVCLabel.text = value
                print(value)
            }
        }
    }
//    @objc func doSomethingAfterNotified() {
//        print("I've been notified")
//        firstVCLabel.text = "Damn, I feel your spark 😱"
//    }
    
    @IBAction func pushVC(_ sender: Any) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "secondVC") as! SecondViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}










