//
//  ViewController.swift
//  Lession7
//
//  Created by Da on 7/20/18.
//  Copyright © 2018 Da. All rights reserved.
//

import UIKit
import UserNotifications

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func notification_touched(_ sender: UIButton) {
        if sender.tag == 1 {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "firstVC") as! FirstViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
        if sender.tag == 2 {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "LocalNotificationsVC") as! LocalNotificationsVC
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
        if sender.tag == 3 {
            let vc = self.storyboard?.instantiateViewController(withIdentifier: "CoreDataViewController") as! CoreDataViewController
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
}

