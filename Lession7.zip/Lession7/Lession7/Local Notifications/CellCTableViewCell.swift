//
//  CellCTableViewCell.swift
//  Lession7
//
//  Created by Da on 7/23/18.
//  Copyright © 2018 Da. All rights reserved.
//

import UIKit

class CellCTableViewCell: UITableViewCell {

    @IBOutlet weak var lblname: UILabel!
    @IBOutlet weak var lbltime: UILabel!
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
