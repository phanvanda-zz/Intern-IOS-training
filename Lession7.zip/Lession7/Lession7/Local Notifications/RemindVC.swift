//
//  RemindVC.swift
//  Lession7
//
//  Created by Da on 7/23/18.
//  Copyright © 2018 Da. All rights reserved.
//

import UIKit
import  UserNotifications
let myNotificationKey = "key"
class RemindVC: UIViewController {
    
    @IBOutlet weak var nameLbl: UITextField!
    @IBOutlet weak var datePicker: UIDatePicker!
    
    var timePick = DateComponents()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func add(_ sender: Any) {
        let name = self.nameLbl.text!
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm"
        self.timePick = self.datePicker.calendar.dateComponents([.day, .month, .year,. hour,.minute], from: self.datePicker.date)
        print("Name: \(name)  Date: \(self.timePick.day!)")
        
        NotificationCenter.default.post(name: Notification.Name(rawValue: myNotificationKey), object: nil, userInfo: ["key": (name:name,date:self.timePick)])
        schedlueNotification(time: self.timePick) { (complete) in
            if complete == true{
                print("Complete!")
            }else{
                print("Error!")
            }
        }
        //self.navigationController?.popViewController(animated: true)
    }
    func schedlueNotification(time: DateComponents, completeHandel: @escaping (_ Sucsecc: Bool) ->()){
        let noti = UNMutableNotificationContent()
        noti.title = "Title"
        noti.subtitle = "Sub title"
        noti.body = "Body"
        let triger = UNCalendarNotificationTrigger(dateMatching: time, repeats: false)
        let request = UNNotificationRequest(identifier: "MyNotification", content: noti, trigger: triger)
        center.add(request) { (error) in
            if error != nil {
                print("ERROR")
                completeHandel(false)
            } else { completeHandel(true) }
        }
    }
}














