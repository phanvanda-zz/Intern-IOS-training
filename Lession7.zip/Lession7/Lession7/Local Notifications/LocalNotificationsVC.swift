//
//  LocalNotificationsVC.swift
//  Lession7
//
//  Created by Da on 7/23/18.
//  Copyright © 2018 Da. All rights reserved.
//

import UIKit

class LocalNotificationsVC: UIViewController {
    var  data = [(name: String,date : DateComponents)] ()
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        let add = UIBarButtonItem(title: "ADD", style: .plain, target: self, action: #selector(adddate))
        self.navigationItem.rightBarButtonItem = add
        
        NotificationCenter.default.addObserver(forName: NSNotification.Name(rawValue: myNotificationKey),
                                               object: nil,
                                               queue: nil,
                                               using:catchNotification(notification:))
    }
    @objc func catchNotification(notification: Notification) {
        if let noti = notification.userInfo {
            if let value = noti["key"] as? (name: String,date : DateComponents) {
               data.append(value)
                self.tableView.reloadData()
            }
        }
    }
    @objc func adddate(){
        let Vc = self.storyboard?.instantiateViewController(withIdentifier: "RemindVC") as! RemindVC
        self.navigationController?.pushViewController(Vc, animated: true)
    }
}
extension LocalNotificationsVC: UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! CellCTableViewCell
        cell.lblname.text = data[indexPath.row].name
        let tmp = "\(data[indexPath.row].date.day!)-\(data[indexPath.row].date.month!)-\(data[indexPath.row].date.year!)  \(data[indexPath.row].date.hour!):\(data[indexPath.row].date.minute!)"
        cell.lbltime.text = tmp
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        return 90
    }
}

