//
//  Excercise2ViewController.swift
//  Lession3
//
//  Created by Da on 7/16/18.
//  Copyright © 2018 Da. All rights reserved.
//

import UIKit

class Excercise2ViewController: UIViewController {
    
    let resultLabel = UILabel()
    let stackView0 = UIStackView()
    var stackView1 = UIStackView()
    var stackView2 = UIStackView()
    var stackView3 = UIStackView()
    var stackView4 = UIStackView()
    var stackView5 = UIStackView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        resultLabel.backgroundColor = UIColor.darkGray
        resultLabel.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(resultLabel)
        resultLabel.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 64).isActive = true
        resultLabel.heightAnchor.constraint(equalTo: self.view.heightAnchor, multiplier: 1/6).isActive = true
        resultLabel.widthAnchor.constraint(equalTo: self.view.widthAnchor).isActive = true
        resultLabel.leftAnchor.constraint(equalTo: self.view.leftAnchor).isActive = true
        resultLabel.text = "1   0  1  "
        resultLabel.textColor = UIColor.white
        resultLabel.textAlignment = .right
        
        
        stackView0.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(stackView0)
        stackView0.topAnchor.constraint(equalTo: resultLabel.bottomAnchor).isActive = true
        stackView0.leftAnchor.constraint(equalTo: self.view.leftAnchor).isActive = true
        stackView0.bottomAnchor.constraint(equalTo: self.view.bottomAnchor).isActive = true
        stackView0.widthAnchor.constraint(equalTo: self.view.widthAnchor).isActive = true
        
        stackView0.axis = .vertical
        stackView0.distribution = .fillEqually
        stackView0.alignment = .fill
        stackView0.spacing = 0
        
        setupStackView(stackViews: stackView1,stackView2,stackView3,stackView4,stackView5)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can berecreated.
    }
    func setupStackView(stackViews: UIStackView...) {
        for stackView in stackViews {
            stackView.axis = .horizontal
            stackView.distribution = .fillEqually
            stackView.alignment = .fill
            stackView.spacing = 0
            stackView.translatesAutoresizingMaskIntoConstraints = false
            self.view.addSubview(stackView)
            
        }
        
        stackView0.addArrangedSubview(stackView1)
        stackView0.addArrangedSubview(stackView2)
        stackView0.addArrangedSubview(stackView3)
        stackView0.addArrangedSubview(stackView4)
        stackView0.addArrangedSubview(stackView5)
        
        stackView1.addButton(title: ["AC","+/-","%","/"])
        stackView2.addButton(title: ["7","8","9","X"])
        stackView3.addButton(title: ["4","5","6","-"])
        stackView4.addButton(title: ["1","2","3","+"])
        stackView5.addButton(title: ["0",".","="])
        
        let button = stackView5.arrangedSubviews.first
        button?.widthAnchor.constraint(equalTo: self.view.widthAnchor, multiplier: 1/2).isActive = true
        let buttonResult = stackView5.arrangedSubviews.last
        buttonResult?.widthAnchor.constraint(equalTo: self.view.widthAnchor, multiplier: 1/4).isActive = true
        let buttonDoc = stackView5.arrangedSubviews[1]
        buttonDoc.widthAnchor.constraint(equalTo: self.view.widthAnchor, multiplier: 1/4).isActive = true
    }
    
}
extension UIStackView {
    func addButton(title: [String]) {
        for text in title {
            let button = UIButton()
            button.setTitle(text, for: .normal)
            button.backgroundColor = UIColor.lightGray
            button.tintColor = UIColor.black
            button.addBorder()
            self.addArrangedSubview(button)
        }
        if let button = self.arrangedSubviews.last {
            button.backgroundColor = UIColor.orange
            button.tintColor = UIColor.white
        }
    }
    func addStackView(){
        
    }
}
extension UIButton {
    func addBorder() {
        
        self.layer.borderWidth = 1
        self.layer.cornerRadius = 1
        self.layer.borderColor = UIColor.black.cgColor
        
    }
}
