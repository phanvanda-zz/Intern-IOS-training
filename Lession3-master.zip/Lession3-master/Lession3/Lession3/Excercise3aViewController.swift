//
//  Excercise3aViewController.swift
//  Lession3
//
//  Created by Da on 7/16/18.
//  Copyright © 2018 Da. All rights reserved.
//

import UIKit

class Excercise3aViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
      
    }
}
