//
//  Excercise1bViewController.swift
//  Lession3
//
//  Created by Da on 7/16/18.
//  Copyright © 2018 Da. All rights reserved.
//

import UIKit

class Excercise1bViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        addView()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    func addView() {
        
        let redView = UIView()
        redView.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(redView)
        
        redView.backgroundColor = UIColor.red
        redView.widthAnchor.constraint(equalTo: self.view.widthAnchor).isActive = true
        redView.heightAnchor.constraint(equalTo: self.view.heightAnchor, multiplier: 1/2).isActive = true
        redView.topAnchor.constraint(equalTo: self.view.topAnchor).isActive = true
        redView.leftAnchor.constraint(equalTo: self.view.leftAnchor).isActive = true
        
        let blueView = UIView()
        blueView.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(blueView)
        
        blueView.backgroundColor = UIColor.blue
        blueView.widthAnchor.constraint(equalTo: redView.widthAnchor, multiplier: 1/2).isActive = true
        blueView.heightAnchor.constraint(equalTo: redView.heightAnchor).isActive = true
        blueView.topAnchor.constraint(equalTo: redView.bottomAnchor).isActive = true
        blueView.leftAnchor.constraint(equalTo: self.view.leftAnchor).isActive = true
    
        let orangeView = UIView()
        orangeView.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(orangeView)
        
        orangeView.backgroundColor = UIColor.orange
        orangeView.widthAnchor.constraint(equalTo: blueView.widthAnchor).isActive = true
        orangeView.heightAnchor.constraint(equalTo: blueView.heightAnchor, multiplier: 1/2).isActive = true
        orangeView.topAnchor.constraint(equalTo: redView.bottomAnchor).isActive = true
        orangeView.leftAnchor.constraint(equalTo: blueView.rightAnchor).isActive = true

        let greenView = UIView()
        greenView.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(greenView)
        
        greenView.backgroundColor = UIColor.green
        greenView.topAnchor.constraint(equalTo: orangeView.bottomAnchor).isActive = true
        greenView.leftAnchor.constraint(equalTo: blueView.rightAnchor).isActive = true
        greenView.heightAnchor.constraint(equalTo: orangeView.heightAnchor).isActive = true
        greenView.widthAnchor.constraint(equalTo: orangeView.widthAnchor, multiplier: 1/2).isActive = true
        
        let whiteView = UIView()
        whiteView.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(whiteView)
        
        whiteView.backgroundColor = UIColor.white
        whiteView.topAnchor.constraint(equalTo: orangeView.bottomAnchor).isActive = true
        whiteView.leftAnchor.constraint(equalTo: greenView.rightAnchor).isActive = true
        
        greenView.heightAnchor.constraint(equalTo: whiteView.heightAnchor).isActive = true
        greenView.widthAnchor.constraint(equalTo: whiteView.widthAnchor).isActive = true
        
    }

}
