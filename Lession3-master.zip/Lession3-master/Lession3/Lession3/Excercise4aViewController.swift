//
//  Excercise4ViewController.swift
//  Lession3
//
//  Created by Da on 7/16/18.
//  Copyright © 2018 Da. All rights reserved.
//

import UIKit

class Excercise4aViewController: UIViewController {

    @IBOutlet weak var login_View: UIView!
    
    @IBOutlet weak var email_View: UIView!
    @IBOutlet weak var password_View: UIView!
    
    @IBOutlet weak var login_Button: UIButton!
    @IBOutlet weak var register_Button: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        login_Button.layer.borderWidth = 1
        login_Button.layer.cornerRadius = 10
        login_Button.layer.borderColor = UIColor.white.cgColor
        
        register_Button.layer.borderWidth = 1
        register_Button.layer.cornerRadius = 10
        register_Button.layer.borderColor = UIColor.white.cgColor
    
        
        email_View.layer.borderWidth = 1
        email_View.layer.cornerRadius = 5
        
        password_View.layer.borderWidth = 1
        password_View.layer.cornerRadius = 5
        
        email_View.layer.borderColor = UIColor.white.cgColor
        password_View.layer.borderColor = UIColor.white.cgColor
        
        login_View.layer.borderWidth = 1
        login_View.layer.cornerRadius = 10
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
