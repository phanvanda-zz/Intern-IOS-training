//
//  MainViewController.swift
//  Lession3
//
//  Created by Da on 7/13/18.
//  Copyright © 2018 Da. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func changeView(_ sender: UIButton) {
        if sender.tag == 1 {
            self.performSegue(withIdentifier: "stackView", sender: nil)
        }
        if sender.tag == 2 {
            self.performSegue(withIdentifier: "Excercise1a", sender: nil)
        }
        if sender.tag == 3 {
            self.performSegue(withIdentifier: "Excercise1b", sender: nil)
        }
        if sender.tag == 4 {
            self.performSegue(withIdentifier: "Excercise2", sender: nil)
        }
        if sender.tag == 5 {
            self.performSegue(withIdentifier: "Excercise3a", sender: nil)
        }
        if sender.tag == 6 {
            self.performSegue(withIdentifier: "Excercise3b", sender: nil)
        }
        if sender.tag == 7 {
            self.performSegue(withIdentifier: "Excercise4a", sender: nil)
        }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "stackView" {
            if let _ = segue.destination as? ViewController {
                
            }
        }
        if segue.identifier == "Excercise1a" {
            if let _ = segue.destination as? Excercise1aViewController {
                
            }
        }
        if segue.identifier == "Excercise1b" {
            if let _ = segue.destination as? Excercise1bViewController {
                
            }
        }
        if segue.identifier == "Excercise2" {
            if let _ = segue.destination as? Excercise2ViewController {
                
            }
        }
        if segue.identifier == "Excercise3a" {
            if let _ = segue.destination as?  Excercise3aViewController {
                
            }
        }
        if segue.identifier == "Excercise3b" {
            if let _ = segue.destination as?  Excercise3bViewController {
                
            }
        }
        if segue.identifier == "Excercise4a" {
            if let _ = segue.destination as? Excercise4aViewController {
                
            }
        }
        if segue.identifier == "Excercise4b" {
            if let _ = segue.destination as? Excercise4bViewController {
                
            }
        }
    }
}
