//
//  Excercise3ViewController.swift
//  Lession3
//
//  Created by Da on 7/16/18.
//  Copyright © 2018 Da. All rights reserved.
//

import UIKit

class Excercise3bViewController: UIViewController {
    let stackView = UIStackView()
    let view1 = UIView()
    let view2 = UIView()
    let view3 = UIView()
    let view4 = UIView()
    let view5 = UIView()
    override func viewDidLoad() {
        super.viewDidLoad()
        view1.backgroundColor = UIColor.red
        view2.backgroundColor = UIColor.red
        view3.backgroundColor = UIColor.red
        view4.backgroundColor = UIColor.red
        view5.backgroundColor = UIColor.red
        
        view.addSubview(stackView)
        stackView.axis = .horizontal
        stackView.alignment = .fill
        stackView.distribution = .fillEqually
        stackView.spacing = 20
        
        stackView.addArrangedSubview(view1)
        stackView.addArrangedSubview(view2)
        stackView.addArrangedSubview(view3)
        stackView.addArrangedSubview(view4)
        stackView.addArrangedSubview(view5)
        let left = NSLayoutConstraint(item: stackView, attribute: .left, relatedBy: .equal, toItem: view, attribute: .left, multiplier: 1, constant: 20)
        
        let right = NSLayoutConstraint(item: stackView, attribute: .right, relatedBy: .equal, toItem: view, attribute: .right, multiplier: 1, constant: -20)
        
        let align = NSLayoutConstraint(item: stackView, attribute: .centerY, relatedBy: .equal, toItem: view, attribute: .centerY, multiplier: 1, constant: 0)
        
        let height = NSLayoutConstraint(item: stackView, attribute: .height, relatedBy: .equal, toItem: view, attribute: .height, multiplier: 1/12, constant: 0)
        
        stackView.autoresizesSubviews = true
        stackView.translatesAutoresizingMaskIntoConstraints = false
        view.addConstraints([left, right, align, height])
    }
    
}
