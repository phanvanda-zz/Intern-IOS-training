//
//  ViewController.swift
//  Lession3
//
//  Created by Da on 7/12/18.
//  Copyright © 2018 Da. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var horizontalStackView: UIStackView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func addStar(_ sender: Any) {
        let starImgVw: UIImageView = UIImageView(image: UIImage(named: "star"))
        starImgVw.contentMode = .scaleAspectFit
        self.horizontalStackView.addArrangedSubview(starImgVw)
        UIView.animate(withDuration: 0.25, animations: {
            self.horizontalStackView.layoutIfNeeded()
        })
    }
    
    @IBAction func removeStar(_ sender: Any) {
        let star:UIView? = self.horizontalStackView.arrangedSubviews.last
        if let aStar = star {
            self.horizontalStackView.removeArrangedSubview(aStar)
            aStar.removeFromSuperview()
            UIView.animate(withDuration: 0.25, animations: {
                self.horizontalStackView.layoutIfNeeded()
            })
        }
    }
    
}

