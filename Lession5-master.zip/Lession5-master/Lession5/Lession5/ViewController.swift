import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var load_indicator: UIActivityIndicatorView!
    @IBOutlet weak var load_uiview: UIView!
    
    @IBOutlet weak var tableView: UITableView!
    var vegetableList = [Vegetable]()
    var moreText = "Click more text"
    override func viewDidLoad() {
        super.viewDidLoad()
        vegetableList = vegetableListOrigin
        tableView.register(UINib(nibName: "VegetableCell", bundle: nil), forCellReuseIdentifier: "VegetableCell")
        
        tableView.rowHeight = UITableViewAutomaticDimension
        tableView.estimatedRowHeight = 40
        
        self.tableView.isEditing = true
        self.tableView.allowsSelectionDuringEditing = true
        //        self.tableView.allowsMultipleSelectionDuringEditing = true
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.keyboardWillShow), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(ViewController.keyboardWillHide), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @objc func keyboardWillShow(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y == 0{
                self.view.frame.origin.y -= keyboardSize.height
            }
        }
    }
    
    @objc func keyboardWillHide(notification: NSNotification) {
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
            if self.view.frame.origin.y != 0{
                self.view.frame.origin.y += keyboardSize.height
            }
        }
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return vegetableList.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "VegetableCell", for: indexPath) as! VegetableCell
        let vegetable = vegetableList[indexPath.row]
        cell.cover_ImageView?.image = UIImage(named: vegetable.imageStr)
        cell.title_Label.text = vegetable.title
        cell.description_Label.text = vegetable.isExpanded ? vegetable.description : moreText
        cell.cover_ImageView.contentMode = .scaleToFill
        cell.cover_ImageView.layer.borderWidth = 1.0
        cell.cover_ImageView.layer.borderColor = UIColor.black.cgColor
        cell.cover_ImageView.layer.cornerRadius = 5.0
        cell.selectionStyle = .none
        return cell
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let cell = tableView.cellForRow(at: indexPath) as? VegetableCell else { return }
        
        let vegetable = vegetableList[indexPath.row]
        vegetable.isExpanded = !vegetable.isExpanded
        vegetableList[indexPath.row] = vegetable
        
        cell.description_Label.text = vegetable.isExpanded ? vegetable.description : moreText
        
        tableView.beginUpdates()
        tableView.endUpdates()
        tableView.scrollToRow(at: indexPath, at: .top, animated: true)
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            print("Deleted")
            
            self.vegetableList.remove(at: indexPath.row)
            self.tableView.deleteRows(at: [indexPath], with: .automatic)
        }
    }
    //    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCellEditingStyle {
    //        return .none
    //    }
    func tableView(_ tableView: UITableView, shouldIndentWhileEditingRowAt indexPath: IndexPath) -> Bool {
        return false
    }
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
//        tableView.beginUpdates()
        var index = IndexPath()
        if destinationIndexPath.row > vegetableList.count {
            index = IndexPath(row: vegetableList.count, section: destinationIndexPath.section)
        } else {
            index = destinationIndexPath
        }
//        tableView.moveRow(at: sourceIndexPath, to: index)
//        tableView.moveRow(at: index, to: sourceIndexPath)
        print(index)
        print(sourceIndexPath)
//        tableView.endUpdates()
        let itemToMove = vegetableList[sourceIndexPath.row]
        vegetableList.remove(at: sourceIndexPath.row)
        vegetableList.insert(itemToMove, at: destinationIndexPath.row)
    }
    func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        let element = vegetableList.count - 1
        if indexPath.row == element {
            loadData() { ()  in
                load_indicator.isHidden = true
                load_uiview.isHidden = true
            }
        }
    }
    func loadData(completion:() -> ()) {
        load_indicator.isHidden = false
        load_uiview.isHidden = false
        self.vegetableList = vegetableListOrigin
        completion()
    }
 
}
























