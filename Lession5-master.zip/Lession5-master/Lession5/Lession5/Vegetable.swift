//
//  Vegetable.swift
//  Lession5
//
//  Created by Da on 7/18/18.
//  Copyright © 2018 Da. All rights reserved.
//

import Foundation
class Vegetable {
    var title: String
    var imageStr: String
    var description: String
    var isExpanded: Bool = false
    init(title: String, imageStr: String, description: String) {
        self.title = title
        self.imageStr = imageStr
        self.description = description
    }
}

var vegetableListOrigin = [
    Vegetable(title: "Rau muống", imageStr: "Ipomoea_aquatica", description: "Rau muống (danh pháp hai phần: Ipomoea aquatica) là một loài thực vật nhiệt đới bán thủy sinh thuộc họ Bìm bìm (Convolvulaceae), là một loại rau ăn lá. Phân bố tự nhiên chính xác của loài này hiện chưa rõ do được trồng phổ biến khắp các vùng nhiệt đới và cận nhiệt đới trên thế giới. Tại Việt Nam, nó là một loại rau rất phổ thông và rất được ưa chuộng."),
    Vegetable(title: "Rau diếp", imageStr: "Lactuca_sativa", description: "Rau diếp hay đôi khi cũng được gọi là xà lách (tên khoa học: Lactuca sativa L. var. longifolia)[1] là một thứ cây trồng thuộc loài Lactuca sativa. So với các thứ rau cùng loài, rau diếp có đầu lá cao hơn, xương lá thẳng và cứng hơn, đồng thời có khả năng chịu nhiệt tốt hơn."),
    Vegetable(title: "Cải ngọt", imageStr: "Brassica_integrifolia", description: "Cải ngọt có nguồn gốc từ Ấn Độ, Trung Quốc. Cây thảo, cao tới 50 - 100 cm, thân tròn, không lông, lá có phiến xoan ngược tròn dài, đầu tròn hay tù, gốc từ từ hẹp, mép nguyên không nhăn, mập, trắng trắng, gân bên 5 - 6 đôi, cuống dài, tròn. Chùm hoa như ngù ở ngọn, cuống hoa dài 3 – 5 cm, hoa vàng tươi, quả cải dài 4 – 11 cm, có mỏ, hạt tròn. Cải ngọt được trồng quanh năm, thời gian sinh trưởng"),
    Vegetable(title: "Cải củ", imageStr: "Raphanus_sativus", description: "Cải củ (danh pháp hai phần: Raphanus sativus) là một loại rau ăn củ thuộc họ Cải, được thuần hóa ở châu Âu[1] từ thời kỳ tiền Roman. Hiện nay cải củ được trồng và sử dụng trên khắp thế giới. Cải củ có nhiều thứ khác nhau, khác biệt về kích thước, màu sắc và mùa vụ. Một vài thứ cải củ được trồng để lấy hạt dùng trong chế biến dầu hạt cải."),
    Vegetable(title: "Rau chân vịt", imageStr: "Spinacia_oleracea", description: "Rau chân vịt hay còn gọi cải bó xôi, rau pố xôi, bố xôi, bắp xôi (danh pháp hai phần: Spinacia oleracea) là một loài thực vật có hoa thuộc họ Dền (Amaranthaceae), có nguồn gốc ở miền Trung và Tây Nam Á. Rau chân vịt là loại rau tốt cho sức khỏe, ngoài ra nó còn là một vị thuốc.")
]

























