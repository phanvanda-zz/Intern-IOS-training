//
//  TableViewCell.swift
//  Lession5
//
//  Created by Da on 7/18/18.
//  Copyright © 2018 Da. All rights reserved.
//

import UIKit

class VegetableCell: UITableViewCell {
    
    @IBOutlet weak var cover_ImageView: UIImageView!
    @IBOutlet weak var title_Label: UILabel!
    @IBOutlet weak var description_Label: UILabel!
    
    
    
//    override func awakeFromNib() {
//        super.awakeFromNib()
//        // Initialization code
//    }
//
//    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//
//        // Configure the view for the selected state
//    }
    
}
