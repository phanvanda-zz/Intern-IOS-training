//
//  ViewController.swift
//  Lession6
//
//  Created by Da on 7/20/18.
//  Copyright © 2018 Da. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        let session = URLSession.shared
        
        let dataTask = session.dataTask(with: URLRequest(url: URL(string: "https://jsonplaceholder.typicode.com/users")!)) { (data, respone, error) in
            if let data = data {
                print(data)
            }
            do {
                let json = try JSONSerialization.jsonObject(with: data!, options: [])
                print(json)
            } catch {
                print(error)
            }
        }
        dataTask.resume()
    }

    @IBAction func onPostTapped(_ sender: Any) {
        let parameters = ["username":"@kilo_loco","tweet": "HelloWord"]
        guard let url = URL(string: "https://jsonplaceholder.typicode.com/posts") else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-type")
        guard let httpBody = try? JSONSerialization.data(withJSONObject: parameters, options: []) else { return }
        
        request.httpBody = httpBody
        
        let session = URLSession.shared
        session.dataTask(with: request) { (data, respone, error) in
            if let respone = respone {
                print(respone)
            }
            
            if let data = data {
                do {
                    let json = try JSONSerialization.jsonObject(with: data, options: [])
                    print(json)
                } catch {
                    print(error)
                }
            }
        }.resume()
    }
    

}

